-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 21 sep. 2020 à 09:47
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `slam3_td3`
--

-- --------------------------------------------------------

--
-- Structure de la table `cb`
--

CREATE TABLE `cb` (
  `ID_COMPTE` varchar(30) NOT NULL,
  `NUM_CARTE` int(11) NOT NULL,
  `ID_CLIENT` varchar(30) NOT NULL,
  `DATE_FERMETURE` date DEFAULT NULL,
  `CODE_CARTE` int(11) DEFAULT NULL,
  `DATE_CARTE` date DEFAULT NULL,
  `ORGANISME_CARTE` varchar(30) DEFAULT NULL,
  `ACTIVATION` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cb`
--

INSERT INTO `cb` (`ID_COMPTE`, `NUM_CARTE`, `ID_CLIENT`, `DATE_FERMETURE`, `CODE_CARTE`, `DATE_CARTE`, `ORGANISME_CARTE`, `ACTIVATION`) VALUES
('A1111', 123456, '123', '2020-09-26', 1234, '2020-09-15', 'VISA', 1);

-- --------------------------------------------------------

--
-- Structure de la table `cheque_indiv`
--

CREATE TABLE `cheque_indiv` (
  `NUM_CHEQUEINDIV` int(11) NOT NULL,
  `num_carnet` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cheque_indiv`
--

INSERT INTO `cheque_indiv` (`NUM_CHEQUEINDIV`, `num_carnet`) VALUES
(147, 369),
(852, 369);

-- --------------------------------------------------------

--
-- Structure de la table `chequier`
--

CREATE TABLE `chequier` (
  `ID_COMPTE` varchar(30) NOT NULL,
  `NUM_CHEQUIER` int(11) NOT NULL,
  `DATE_CHEQUIER` date DEFAULT NULL,
  `PREMIER_CHEQUE` int(11) DEFAULT NULL,
  `DERNIER_CHEQUE` int(11) DEFAULT NULL,
  `ACTIVATION` tinyint(1) DEFAULT NULL,
  `DESTRUCTION` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `chequier`
--

INSERT INTO `chequier` (`ID_COMPTE`, `NUM_CHEQUIER`, `DATE_CHEQUIER`, `PREMIER_CHEQUE`, `DERNIER_CHEQUE`, `ACTIVATION`, `DESTRUCTION`) VALUES
('A1111', 369, '2020-09-24', 124, 521, 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `ID_CLIENT` varchar(30) NOT NULL,
  `NOM_CLIENT` varchar(30) DEFAULT NULL,
  `PRENOM_CLIENT` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`ID_CLIENT`, `NOM_CLIENT`, `PRENOM_CLIENT`) VALUES
('123', 'Chauvin', 'Karen'),
('456', 'Chauvin', 'Alexandre');

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `ID_COMPTE` varchar(30) NOT NULL,
  `DATE_OUVERTURE` date DEFAULT NULL,
  `DATE_FERMETURE` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compte`
--

INSERT INTO `compte` (`ID_COMPTE`, `DATE_OUVERTURE`, `DATE_FERMETURE`) VALUES
('A1111', '2020-09-16', '2020-09-30'),
('B2222', '2020-09-18', '2020-09-26');

-- --------------------------------------------------------

--
-- Structure de la table `moyen_paiment`
--

CREATE TABLE `moyen_paiment` (
  `NOM_MOYEN` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `moyen_paiment`
--

INSERT INTO `moyen_paiment` (`NOM_MOYEN`) VALUES
('Carte paiement'),
('Cheque');

-- --------------------------------------------------------

--
-- Structure de la table `operation`
--

CREATE TABLE `operation` (
  `ID_OPERATION` varchar(30) NOT NULL,
  `id_client` int(11) NOT NULL,
  `moyen_paiment` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `operation`
--

INSERT INTO `operation` (`ID_OPERATION`, `id_client`, `moyen_paiment`) VALUES
('25', 123, 'Carte paiement'),
('45', 456, 'Cheque');

-- --------------------------------------------------------

--
-- Structure de la table `organisme_carte`
--

CREATE TABLE `organisme_carte` (
  `id_organisme` int(11) NOT NULL,
  `nom_organisme` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `organisme_carte`
--

INSERT INTO `organisme_carte` (`id_organisme`, `nom_organisme`) VALUES
(1, 'Visa'),
(2, 'Mastercard');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cb`
--
ALTER TABLE `cb`
  ADD PRIMARY KEY (`ID_COMPTE`,`NUM_CARTE`),
  ADD KEY `APPARTENIR_FK` (`ID_CLIENT`),
  ADD KEY `HERITAGE_2_FK` (`ID_COMPTE`);

--
-- Index pour la table `cheque_indiv`
--
ALTER TABLE `cheque_indiv`
  ADD PRIMARY KEY (`NUM_CHEQUEINDIV`);

--
-- Index pour la table `chequier`
--
ALTER TABLE `chequier`
  ADD PRIMARY KEY (`ID_COMPTE`,`NUM_CHEQUIER`),
  ADD KEY `HERITAGE_1_FK` (`ID_COMPTE`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`ID_CLIENT`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`ID_COMPTE`);

--
-- Index pour la table `moyen_paiment`
--
ALTER TABLE `moyen_paiment`
  ADD PRIMARY KEY (`NOM_MOYEN`);

--
-- Index pour la table `operation`
--
ALTER TABLE `operation`
  ADD PRIMARY KEY (`ID_OPERATION`),
  ADD KEY `id_client` (`id_client`);

--
-- Index pour la table `organisme_carte`
--
ALTER TABLE `organisme_carte`
  ADD PRIMARY KEY (`id_organisme`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
