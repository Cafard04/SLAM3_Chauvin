BEGIN
  RETURN (SELECT COUNT(DISTINCT facture.num) 
          FROM facture,client 
          WHERE facture.client = parameter01);
END;




