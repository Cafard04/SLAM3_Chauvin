select client.*, function03(client.num), function02(client.num) 
FROM client;



