BEGIN
  RETURN (SELECT
      SUM(ligne_fact.qte * produit.prix)
    FROM facture,
         ligne_fact,
         produit
    WHERE produit.num = ligne_fact.produit
    AND ligne_fact.facture = facture.num
    AND facture.client = parameter01);
END;




