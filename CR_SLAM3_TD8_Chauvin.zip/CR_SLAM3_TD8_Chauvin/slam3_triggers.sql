-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 05 déc. 2020 à 12:27
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `slam3_triggers`
--

-- --------------------------------------------------------

--
-- Structure de la table `affecter`
--

CREATE TABLE `affecter` (
  `num_client` int(11) NOT NULL,
  `date` date NOT NULL,
  `num_agence` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `affecter`
--

INSERT INTO `affecter` (`num_client`, `date`, `num_agence`) VALUES
(1, '2012-10-27', 3),
(3, '2012-11-01', 1),
(3, '2012-11-03', NULL),
(2, '2012-11-02', 3),
(4, '2012-11-01', 2),
(5, '2012-11-02', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

CREATE TABLE `agence` (
  `num_agence` int(11) NOT NULL,
  `nom_agence` varchar(50) DEFAULT NULL,
  `adresse_agence` varchar(192) DEFAULT NULL,
  `tel_agence` char(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `agence`
--

INSERT INTO `agence` (`num_agence`, `nom_agence`, `adresse_agence`, `tel_agence`) VALUES
(1, 'CAEN Centre', '13 Rue St Pierre, 14000 CAEN', '0233456789'),
(3, 'Lannion', '2 bis Rue de Brelevenez, 22300 LANNION', '0232564345'),
(2, 'Nogent sur Marne', '12 Bd de Strasbourg, 94230 Nogent sur Marne', '0145232356');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `num_client` int(11) NOT NULL,
  `nom_client` varchar(30) DEFAULT NULL,
  `prenom_client` varchar(30) DEFAULT NULL,
  `adresse_client` varchar(192) DEFAULT NULL,
  `identifiant_internet` varchar(30) DEFAULT NULL,
  `mdp_internet` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`num_client`, `nom_client`, `prenom_client`, `adresse_client`, `identifiant_internet`, `mdp_internet`) VALUES
(1, 'DUPONT', 'Pierre', '5 Rue du Port, 22300 LANNION', 'Pdupont', 'Pdupont'),
(2, 'DUPONT', 'Annie', '5 Rue du Port, 22300 LANNION', 'Adupont', 'Adupont'),
(3, 'DELAVAL', 'Jean', '12 Bd de l\'Orne, 14234 OUISTREHAM', 'Jdelaval', 'Jdelaval'),
(4, 'HANOT', 'Eric', '13 Avenue de Neuilly, 94230 NOGENT SUR MARNE', 'Ehanot', 'Ehanot'),
(5, 'LEVY', 'Sarah', '1 Rue Neuve, 14110 CONDE SUR NOIREAU', 'Slevy', 'Slevy'),
(7, 'gege', 'gege', 'gege', 'Ggege', 'Ggege');

--
-- Déclencheurs `client`
--
DELIMITER $$
CREATE TRIGGER `param_client` BEFORE INSERT ON `client` FOR EACH ROW BEGIN
   SET NEW.identifiant_internet = CONCAT(UCASE(SUBSTRING(NEW.prenom_client,1,1)), LOWER(NEW.nom_client ));
  
  SET NEW.mdp_internet = CONCAT(UCASE(SUBSTRING(NEW.prenom_client,1,1)), LOWER(NEW.nom_client ));

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `id_type` smallint(6) NOT NULL,
  `num_compte` int(11) NOT NULL,
  `date_fermer` date DEFAULT NULL,
  `date_ouvrir` date NOT NULL,
  `solde` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compte`
--

INSERT INTO `compte` (`id_type`, `num_compte`, `date_fermer`, `date_ouvrir`, `solde`) VALUES
(1, 1, NULL, '2012-10-27', 700),
(2, 1, NULL, '2012-11-01', 1900),
(1, 3, NULL, '2012-11-02', 3400),
(1, 4, NULL, '2012-11-01', 4000),
(1, 5, NULL, '2012-10-27', -1200),
(2, 5, NULL, '2012-10-27', 700);

-- --------------------------------------------------------

--
-- Structure de la table `date`
--

CREATE TABLE `date` (
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `date`
--

INSERT INTO `date` (`date`) VALUES
('2012-01-01'),
('2012-10-27'),
('2012-11-01'),
('2012-11-02'),
('2012-11-03'),
('2012-12-31');

-- --------------------------------------------------------

--
-- Structure de la table `operation`
--

CREATE TABLE `operation` (
  `id_operation` bigint(20) NOT NULL,
  `num_compte` int(11) NOT NULL,
  `date` date NOT NULL,
  `id_type` smallint(6) NOT NULL,
  `id_type_vers` smallint(6) DEFAULT NULL,
  `num_compte_vers` int(11) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `type_operation` varchar(20) DEFAULT NULL,
  `montant` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `operation`
--

INSERT INTO `operation` (`id_operation`, `num_compte`, `date`, `id_type`, `id_type_vers`, `num_compte_vers`, `designation`, `type_operation`, `montant`) VALUES
(1, 1, '2012-10-27', 1, NULL, NULL, 'Ouverture compte', 'CREDIT', 100),
(2, 1, '2012-11-01', 1, NULL, NULL, 'Versement', 'CREDIT', 900),
(3, 1, '2012-11-01', 2, NULL, NULL, 'Versement Ouverture', 'CREDIT', 2000),
(4, 3, '2012-11-02', 1, NULL, NULL, 'Paye Novembre', 'CREDIT', 5000),
(5, 3, '2012-11-03', 1, NULL, NULL, 'Loyer Novembre', 'DEBIT', 1200),
(6, 3, '2012-11-03', 1, NULL, NULL, 'EDF', 'DEBIT', 400),
(7, 4, '2012-11-01', 1, NULL, NULL, 'Paye Novembre 2012', 'CREDIT', 3500),
(8, 4, '2012-11-01', 1, NULL, NULL, 'Pension', 'CREDIT', 1000),
(9, 4, '2012-11-02', 1, NULL, NULL, 'Rbt CREDIT immobilier', 'DEBIT', 500),
(10, 5, '2012-10-27', 1, NULL, NULL, 'Paye', 'CREDIT', 2500),
(11, 5, '2012-10-27', 1, 2, 5, 'Virement', 'VIREMENT', 500),
(12, 1, '2020-11-30', 1, 2, 5, 'virreeeeemment', 'VIREMENT', 100);

--
-- Déclencheurs `operation`
--
DELIMITER $$
CREATE TRIGGER `verif_compte` BEFORE UPDATE ON `operation` FOR EACH ROW BEGIN
   
     IF
     	NEW.type_operation != 'VIREMENT' 
     THEN 
       SIGNAL sqlstate '45000' SET message_text = 'Le transfert nest pas de type virement';
     END IF;
       
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `verif_insert` BEFORE INSERT ON `operation` FOR EACH ROW BEGIN
    IF NEW.type_operation != 'VIREMENT' 
      THEN
        SIGNAL sqlstate '45000' SET message_text = 'paaaaas biiiieeennn';
	ELSE
    	UPDATE compte SET solde=solde-NEW.montant 
        WHERE num_compte=NEW.num_compte 
        AND id_type=NEW.id_type ;
            
        UPDATE compte SET solde=solde+NEW.montant 
        WHERE num_compte=NEW.num_compte_vers
        AND id_type=NEW.id_type_vers;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `posseder`
--

CREATE TABLE `posseder` (
  `num_client` int(11) NOT NULL,
  `id_type` smallint(6) NOT NULL,
  `num_compte` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `posseder`
--

INSERT INTO `posseder` (`num_client`, `id_type`, `num_compte`) VALUES
(1, 1, 1),
(1, 2, 1),
(2, 1, 1),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(5, 2, 5);

-- --------------------------------------------------------

--
-- Structure de la table `remunerer`
--

CREATE TABLE `remunerer` (
  `date` date NOT NULL,
  `date_de` date NOT NULL,
  `id_type` smallint(6) NOT NULL,
  `taux_interet` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `remunerer`
--

INSERT INTO `remunerer` (`date`, `date_de`, `id_type`, `taux_interet`) VALUES
('2012-11-01', '2012-01-01', 2, 2),
('2012-12-31', '2012-11-02', 2, 4),
('2020-11-11', '2020-11-03', 2, 5);

--
-- Déclencheurs `remunerer`
--
DELIMITER $$
CREATE TRIGGER `remun` BEFORE INSERT ON `remunerer` FOR EACH ROW BEGIN
DECLARE daatee date ;

SET daatee =(SELECT MAX(date) FROM remunerer WHERE id_type = NEW.id_type);
          
		IF (NEW.date_de<daatee)
        THEN 
       	   	SIGNAL sqlstate '45000' SET message_text = 'La date saisie nest pas référencable (car inférieure)';
          	
    END IF; 
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `type_compte`
--

CREATE TABLE `type_compte` (
  `id_type` smallint(6) NOT NULL,
  `designation` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_compte`
--

INSERT INTO `type_compte` (`id_type`, `designation`) VALUES
(1, 'Compte Courant'),
(2, 'Livret A');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `affecter`
--
ALTER TABLE `affecter`
  ADD PRIMARY KEY (`num_client`,`date`),
  ADD KEY `fk_affecter_agence` (`num_agence`),
  ADD KEY `fk_affecter_date` (`date`);

--
-- Index pour la table `agence`
--
ALTER TABLE `agence`
  ADD PRIMARY KEY (`num_agence`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`num_client`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`id_type`,`num_compte`),
  ADD KEY `fk_compte_date` (`date_fermer`),
  ADD KEY `fk_compte_date2` (`date_ouvrir`);

--
-- Index pour la table `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`date`);

--
-- Index pour la table `operation`
--
ALTER TABLE `operation`
  ADD PRIMARY KEY (`id_operation`),
  ADD KEY `fk_operation_compte` (`id_type`,`num_compte`),
  ADD KEY `fk_operation_compte1` (`id_type_vers`,`num_compte_vers`),
  ADD KEY `fk_operation_date` (`date`);

--
-- Index pour la table `posseder`
--
ALTER TABLE `posseder`
  ADD PRIMARY KEY (`num_client`,`id_type`,`num_compte`),
  ADD KEY `fk_posseder_compte` (`id_type`,`num_compte`);

--
-- Index pour la table `remunerer`
--
ALTER TABLE `remunerer`
  ADD PRIMARY KEY (`date`,`date_de`,`id_type`),
  ADD KEY `fk_remunerer_date1` (`date_de`),
  ADD KEY `fk_remunerer_type_compte` (`id_type`);

--
-- Index pour la table `type_compte`
--
ALTER TABLE `type_compte`
  ADD PRIMARY KEY (`id_type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
