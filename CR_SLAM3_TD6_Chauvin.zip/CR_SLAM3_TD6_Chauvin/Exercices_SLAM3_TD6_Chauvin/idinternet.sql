﻿CREATE OR REPLACE FUNCTION create_id_internet(numcliente INT, nom VARCHAR, prenom VARCHAR) RETURNS VARCHAR
LANGUAGE plpgsql
AS $plpgsql$
 DECLARE
  var1 TEXT;
  var2 TEXT;
  var3 TEXT;
BEGIN
  var1 = UPPER(SUBSTR(prenom, 0,2)) ;
  var2 = LOWER(nom);
  var3 = var1 || var2;
  UPDATE client SET identifiant_internet = var3, mdp_internet=var3 WHERE client.num_client=numcliente;
  RETURN var3;
END;
$plpgsql$;


SELECT create_id_internet(7,'Chauvin', 'Karen') ;