﻿
CREATE OR REPLACE FUNCTION  getNbJoursParMois3(datee date) RETURNS DATE AS
$$
  SELECT (date_trunc('MONTH', $1) + INTERVAL '1 MONTH - 1 day')::DATE;
  
$$
LANGUAGE 'sql';



CREATE OR REPLACE FUNCTION creer_date(mois INT, annee int) RETURNS DATE
LANGUAGE plpgsql
AS $plpgsql$
DECLARE 
    nbjour INT;
    i INT;
BEGIN
   
    nbjour = date_part('day',getNbJoursParMois3('2020-01-01')) ;

    FOR i IN 1..nbJour LOOP
        INSERT INTO DATE(date) VALUES "annee-mois-i";
END;
$plpgsql$;


