﻿CREATE OR REPLACE FUNCTION creer_user_client() RETURNS VARCHAR
LANGUAGE plpgsql
AS $plpgsql$
DECLARE
  nbcli INT;
  nbcli2 INT;
BEGIN
  nbcli = COUNT(identifiant_internet) FROM client;
  nbcli2 = 0;

      
   FOR i IN 1..nbcli LOOP
     IF NOT EXISTS (SELECT * FROM pg_user WHERE id_internet = 'identifiant_internet') THEN
          CREATE ROLE identifiant_internet with PASSWORD 'mdp_internet';
          nbcli2 = nbcli2+1;
    END IF;
    END LOOP;

  

  RETURN nbcli2;
END;
$plpgsql$;



 SELECT  creer_user_client();