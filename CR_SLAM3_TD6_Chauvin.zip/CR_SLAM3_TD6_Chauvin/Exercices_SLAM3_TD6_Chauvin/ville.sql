﻿CREATE or REPLACE FUNCTION comptville(ville VARCHAR) RETURNS INT
LANGUAGE plpgsql
AS $plpgsql$
BEGIN
  RETURN COUNT( DISTINCT client.num_client) FROM client WHERE client.adresse_client LIKE ('%' || ville || '%'); 
END;
$plpgsql$;


SELECT comptville('LANNION') ;