﻿CREATE OR REPLACE FUNCTION  nb_operation_compte_mois(mois INT, year INT, numcompte int) 
RETURNS INT
LANGUAGE plpgsql
AS $plpgsql$
BEGIN
  RETURN COUNT(DISTINCT operation.id_operation) 
  FROM operation 
  WHERE numcompte=operation.num_compte 
  AND date_part('month',operation.date)=mois 
  AND date_part('year',operation.date)=year;
END;
$plpgsql$;


SELECT nb_operation_compte_mois(10, 2012, 5) ;

