﻿
CREATE OR REPLACE FUNCTION  getNbJoursParMois3(datee date) RETURNS DATE AS
$$
  SELECT (date_trunc('MONTH', $1) + INTERVAL '1 MONTH - 1 day')::DATE;
  
$$
LANGUAGE 'sql';



CREATE OR REPLACE FUNCTION creer_date2(mois varchar, annee varchar) RETURNS VARCHAR
LANGUAGE plpgsql
AS $plpgsql$
DECLARE 
    nbjour INT;
    i VARCHAR;
    datee DATE;
BEGIN
   
 /*   i = annee ||'-' || mois || '-'|| '01';*/
    datee = TO_DATE(annee || mois || '01','YYYYMMDD');
    nbjour = date_part('day',getNbJoursParMois3(datee)) ;
   
    
    FOR i IN 1..nbJour LOOP
       INSERT INTO DATE(date) VALUES ( TO_DATE(annee || mois || i,'YYYYMMDD'));
      
END LOOP;

    RETURN TO_DATE(annee || mois || i,'YYYYMMDD');
  
END;

$plpgsql$;

SELECT creer_date2('08','2001') ;
