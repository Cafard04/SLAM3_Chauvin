/***********************************************************************
 * Module:  S_occuper.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class S_occuper
 ***********************************************************************/

import java.util.*;

/** @pdOid 26899300-9884-47f6-a98a-44c0b6d64542 */
public class S_occuper {
   /** @pdOid a403733b-98b3-40d5-88ac-e7e3c2c76d0f */
   public double prix;
   
   /** @pdRoleInfo[ migr=no] name=TypeService assc=s_occuper mult=0..* side=A */
   public TypeService[] s_occuperA;
   /** @pdRoleInfo migr=no name=Appareil assc=s_occuper mult=0..* */
   public Appareil[] s_occuperB;

}