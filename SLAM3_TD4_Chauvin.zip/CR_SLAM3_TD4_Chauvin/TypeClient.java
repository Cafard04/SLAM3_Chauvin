/***********************************************************************
 * Module:  TypeClient.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class TypeClient
 ***********************************************************************/

import java.util.*;

/** @pdOid 6f563ecc-eb7a-4cad-a0bd-7cac982589b6 */
public class TypeClient {
   /** @pdOid 2dafb4fd-8754-456e-9e25-5913e598bb73 */
   public java.lang.String idType;
   /** @pdOid 5aee870c-a68f-49af-99ff-49a16978777e */
   public java.lang.String nomType;
   
   /** @pdRoleInfo[ migr=no] name=Client assc=etre mult=1..* side=A */
   public Client[] etre;
   public Conditionner conditionner;

}