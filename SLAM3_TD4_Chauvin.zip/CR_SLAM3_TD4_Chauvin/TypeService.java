/***********************************************************************
 * Module:  TypeService.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class TypeService
 ***********************************************************************/

import java.util.*;

/** @pdOid 4d64f3a4-5880-48f8-8cb5-b0a0b8fbe9fd */
public class TypeService {
   /** @pdOid 08f753c8-d9a5-4c93-bd54-8fe9d890b54c */
   public int idSer;
   /** @pdOid 222762bf-e374-47d4-94de-bd597e8b123c */
   public java.lang.String type;
   
   public S_occuper s_occuper;
   /** @pdRoleInfo[ migr=no] name=Dossier assc=avoir mult=0..* side=A */
   public Dossier[] avoir;

}