/***********************************************************************
 * Module:  Appareil.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class Appareil
 ***********************************************************************/

import java.util.*;

/** @pdOid f5e542fe-e1a3-4fd8-985e-4e42729e55df */
public class Appareil {
   /** @pdOid 89094438-bad9-4f96-8fad-f6f16fba85c6 */
   public int idApp;
   /** @pdOid 860b4556-194d-459b-b2ea-4c65546344cb */
   public int appareil;
   
   public Conditionner conditionner;
   /** @pdRoleInfo[ migr=no] name=Dossier assc=gerer mult=0..* side=A */
   public Dossier[] gerer;
   public S_occuper s_occuper;

}