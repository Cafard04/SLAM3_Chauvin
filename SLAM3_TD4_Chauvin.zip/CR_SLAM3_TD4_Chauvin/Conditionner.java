/***********************************************************************
 * Module:  Conditionner.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class Conditionner
 ***********************************************************************/

import java.util.*;

/** @pdOid a2798171-07f6-482d-a1a0-60f4f41ebce0 */
public class Conditionner {
   /** @pdOid 00835a52-c5a2-43a9-bc9f-c1093da4336f */
   public java.lang.String avance;
   
   /** @pdRoleInfo[ migr=no] name=Appareil assc=conditionner mult=0..* side=A */
   public Appareil[] conditionnerA;
   /** @pdRoleInfo migr=no name=TypeClient assc=conditionner mult=0..* */
   public TypeClient[] conditionnerB;

}