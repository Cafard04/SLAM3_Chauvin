/***********************************************************************
 * Module:  Client.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class Client
 ***********************************************************************/

import java.util.*;

/** @pdOid 67181df7-3cf1-459a-8d14-40060571b317 */
public class Client {
   /** @pdOid 2426e40c-a82b-4484-9f17-b919be75cdd2 */
   public int idClient;
   /** @pdOid 7413d2f0-3c68-4f4a-a40b-df3cd1b52af0 */
   public java.lang.String nom;
   /** @pdOid d49aeeb8-cb82-4ec9-9faa-e989e095c619 */
   public java.lang.String prenom;
   /** @pdOid ff67a5f4-1a64-4512-9453-9736d321749b */
   public java.lang.String adresse;
   /** @pdOid f3535fdf-0e2e-4f92-9e64-58139acb3a49 */
   public java.lang.String cp;
   /** @pdOid 11fd6d1f-5b12-46b9-a4c2-fc36b6a90cc7 */
   public java.lang.String ville;
   /** @pdOid 33119690-5306-432b-b040-3ea0916a71b7 */
   public java.lang.String tel;
   /** @pdOid c16cd886-53c4-4f09-9a07-c3a45e2ee5b8 */
   public java.lang.String type;
   
   /** @pdRoleInfo[ migr=no] name=Dossier assc=etablir mult=0..* side=A */
   public Dossier[] etablir;

}