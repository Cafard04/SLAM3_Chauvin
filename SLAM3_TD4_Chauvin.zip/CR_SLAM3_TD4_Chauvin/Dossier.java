/***********************************************************************
 * Module:  Dossier.java
 * Author:  Karen Chauvin
 * Purpose: Defines the Class Dossier
 ***********************************************************************/

import java.util.*;

/** @pdOid d636120d-0406-428f-ba55-592f2e2be564 */
public class Dossier {
   /** @pdOid 03575fdc-cc15-4d04-95cc-c0bcd137461a */
   public int idAppareil;
   /** @pdOid 1d818239-0fb2-4a39-bad1-53b47c388607 */
   public java.lang.String avance;
   /** @pdOid 77e0a6a2-35c7-4355-93af-6b85144f5870 */
   public java.lang.String service;
   /** @pdOid e8c896c0-306b-453a-b01f-fe060193dcf0 */
   public java.lang.String express;
   /** @pdOid 5f6d8a3a-6017-4761-a5ce-134948417969 */
   public java.util.Date dateEntree;

}